import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { API_URL } from '../../api';

export default function DriverLogin() {
  const navigate = useNavigate();
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (localStorage.getItem('driver_token')) {
      navigate('/driver');
    }
  }, [navigate]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`${API_URL}/api/v1/driver-portal/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, password }),
      });
      const json = await res.json();
      if (!res.ok || json.error) {
        setError(json.error || 'Login gagal. Periksa nomor HP dan password.');
      } else {
        localStorage.setItem('driver_token', json.data.token);
        localStorage.setItem('driver_user', JSON.stringify(json.data.driver));
        navigate('/driver');
      }
    } catch {
      setError('Tidak dapat terhubung ke server. Periksa koneksi internet Anda.');
    }
    setLoading(false);
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '24px',
    }}>
      <div style={{
        background: '#fff',
        borderRadius: 20,
        padding: '40px 32px',
        width: '100%',
        maxWidth: 400,
        boxShadow: '0 20px 60px rgba(0,0,0,0.4)',
      }}>
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div style={{
            width: 72, height: 72, borderRadius: 18,
            background: 'linear-gradient(135deg, #e53935, #b71c1c)',
            margin: '0 auto 16px',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <span className="material-icons" style={{ fontSize: 36, color: '#fff' }}>local_shipping</span>
          </div>
          <h1 style={{ margin: '0 0 6px', fontSize: 22, fontWeight: 700, color: '#1a1a2e' }}>Driver Portal</h1>
          <p style={{ margin: 0, color: '#757575', fontSize: 14 }}>Masuk untuk melihat tugas pengiriman</p>
        </div>

        {error && (
          <div style={{
            background: '#ffebee', border: '1px solid #ef9a9a',
            borderRadius: 10, padding: '12px 16px',
            color: '#b71c1c', fontSize: 13, marginBottom: 20,
            display: 'flex', gap: 8, alignItems: 'center',
          }}>
            <span className="material-icons" style={{ fontSize: 18 }}>error_outline</span>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: '#424242', marginBottom: 6 }}>
              Nomor HP / Email
            </label>
            <input
              style={{
                width: '100%', padding: '12px 14px', borderRadius: 10,
                border: '1.5px solid #e0e0e0', fontSize: 15,
                outline: 'none', boxSizing: 'border-box',
                transition: 'border-color 0.2s',
              }}
              type="text"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              required
              autoFocus
              placeholder="08xx xxxx xxxx"
              onFocus={e => (e.target.style.borderColor = '#e53935')}
              onBlur={e => (e.target.style.borderColor = '#e0e0e0')}
            />
          </div>
          <div style={{ marginBottom: 24 }}>
            <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: '#424242', marginBottom: 6 }}>
              Password
            </label>
            <input
              style={{
                width: '100%', padding: '12px 14px', borderRadius: 10,
                border: '1.5px solid #e0e0e0', fontSize: 15,
                outline: 'none', boxSizing: 'border-box',
                transition: 'border-color 0.2s',
              }}
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
              placeholder="Masukkan password"
              onFocus={e => (e.target.style.borderColor = '#e53935')}
              onBlur={e => (e.target.style.borderColor = '#e0e0e0')}
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            style={{
              width: '100%', padding: '14px',
              background: loading ? '#bdbdbd' : 'linear-gradient(135deg, #e53935, #b71c1c)',
              color: '#fff', border: 'none', borderRadius: 10,
              fontSize: 16, fontWeight: 600, cursor: loading ? 'not-allowed' : 'pointer',
              transition: 'opacity 0.2s',
            }}
          >
            {loading ? 'Memproses...' : 'Masuk'}
          </button>
        </form>
      </div>

      <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: 12, marginTop: 24 }}>
        Open TMS Driver Portal
      </p>
    </div>
  );
}
