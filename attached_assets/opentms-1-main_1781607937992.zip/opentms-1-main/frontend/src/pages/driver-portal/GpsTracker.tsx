import React, { useEffect } from 'react';
import { useGpsTracking } from './useGpsTracking';

interface GpsTrackerProps {
  loadId: string;
  autoStart?: boolean;
}

export default function GpsTracker({ loadId, autoStart = false }: GpsTrackerProps) {
  const { status, startTracking, stopTracking } = useGpsTracking(loadId);

  useEffect(() => {
    if (autoStart) startTracking();
    return () => stopTracking();
  }, [loadId]);

  function formatTime(d: Date | null) {
    if (!d) return '—';
    return d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }

  const dotColor = status.active ? '#43a047' : status.error ? '#e53935' : '#9e9e9e';

  return (
    <div style={{
      background: '#fff', borderRadius: 16, padding: 16,
      marginBottom: 12, boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
    }}>
      {/* Header row */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 38, height: 38, borderRadius: 12,
            background: status.active ? '#e8f5e9' : '#f5f5f5',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <span className="material-icons" style={{ color: status.active ? '#43a047' : '#9e9e9e', fontSize: 22 }}>
              gps_fixed
            </span>
          </div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 700, color: '#212121' }}>Pelacak Lokasi GPS</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 2 }}>
              <div style={{
                width: 7, height: 7, borderRadius: 4, background: dotColor,
                boxShadow: status.active ? `0 0 0 3px ${dotColor}33` : 'none',
                animation: status.active ? 'gpsPulse 1.5s ease-in-out infinite' : 'none',
              }} />
              <span style={{ fontSize: 11, color: status.active ? '#43a047' : '#9e9e9e', fontWeight: 600 }}>
                {status.active ? 'Aktif — melacak' : status.error ? 'Error' : 'Tidak aktif'}
              </span>
            </div>
          </div>
        </div>

        {/* Toggle button */}
        <button
          onClick={status.active ? stopTracking : startTracking}
          style={{
            padding: '9px 18px', borderRadius: 10, border: 'none', cursor: 'pointer',
            background: status.active
              ? '#ffebee'
              : 'linear-gradient(135deg, #2e7d32, #43a047)',
            color: status.active ? '#e53935' : '#fff',
            fontSize: 13, fontWeight: 700,
            display: 'flex', alignItems: 'center', gap: 6,
            boxShadow: status.active ? 'none' : '0 3px 10px rgba(67,160,71,0.35)',
            transition: 'all 0.2s',
          }}
        >
          <span className="material-icons" style={{ fontSize: 18 }}>
            {status.active ? 'gps_off' : 'gps_fixed'}
          </span>
          {status.active ? 'Stop' : 'Mulai'}
        </button>
      </div>

      {/* Error */}
      {status.error && (
        <div style={{
          background: '#ffebee', borderRadius: 10, padding: '10px 12px',
          color: '#b71c1c', fontSize: 12, display: 'flex', gap: 8, alignItems: 'flex-start',
          marginBottom: 10,
        }}>
          <span className="material-icons" style={{ fontSize: 16, flexShrink: 0 }}>warning</span>
          {status.error}
        </div>
      )}

      {/* Info rows */}
      {status.active && (
        <div style={{
          background: '#f8f9fa', borderRadius: 12, padding: '12px',
          display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10,
        }}>
          {status.coords && (
            <>
              <div>
                <div style={{ fontSize: 10, color: '#9e9e9e', marginBottom: 2 }}>LATITUDE</div>
                <div style={{ fontSize: 13, fontWeight: 600, color: '#212121', fontFamily: 'monospace' }}>
                  {status.coords.lat.toFixed(6)}
                </div>
              </div>
              <div>
                <div style={{ fontSize: 10, color: '#9e9e9e', marginBottom: 2 }}>LONGITUDE</div>
                <div style={{ fontSize: 13, fontWeight: 600, color: '#212121', fontFamily: 'monospace' }}>
                  {status.coords.lng.toFixed(6)}
                </div>
              </div>
              <div>
                <div style={{ fontSize: 10, color: '#9e9e9e', marginBottom: 2 }}>AKURASI</div>
                <div style={{ fontSize: 13, fontWeight: 600, color: status.coords.accuracy < 30 ? '#43a047' : status.coords.accuracy < 100 ? '#f57c00' : '#e53935' }}>
                  ±{status.coords.accuracy} m
                  <span style={{ fontSize: 10, fontWeight: 400, color: '#9e9e9e', marginLeft: 4 }}>
                    {status.coords.accuracy < 30 ? 'Sangat baik' : status.coords.accuracy < 100 ? 'Cukup' : 'Lemah'}
                  </span>
                </div>
              </div>
              <div>
                <div style={{ fontSize: 10, color: '#9e9e9e', marginBottom: 2 }}>TERKIRIM KE SERVER</div>
                <div style={{ fontSize: 12, fontWeight: 600, color: '#212121', display: 'flex', alignItems: 'center', gap: 4 }}>
                  {status.sending ? (
                    <><span className="material-icons" style={{ fontSize: 14, color: '#1976d2', animation: 'spin 0.8s linear infinite' }}>sync</span> Mengirim...</>
                  ) : status.lastSent ? (
                    <><span className="material-icons" style={{ fontSize: 14, color: '#43a047' }}>cloud_done</span> {formatTime(status.lastSent)}</>
                  ) : (
                    <span style={{ color: '#9e9e9e' }}>Belum terkirim</span>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {/* Open own location in maps */}
      {status.active && status.coords && (
        <button
          onClick={() => window.open(
            `https://www.google.com/maps?q=${status.coords!.lat},${status.coords!.lng}`,
            '_blank'
          )}
          style={{
            width: '100%', marginTop: 10, padding: '11px',
            background: '#f0f7ff', border: '1.5px solid #bbdefb',
            borderRadius: 12, color: '#1976d2', fontSize: 13,
            fontWeight: 600, cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
            boxSizing: 'border-box',
          }}
        >
          <span className="material-icons" style={{ fontSize: 18 }}>my_location</span>
          Lihat Posisi Saya di Maps
        </button>
      )}

      <style>{`
        @keyframes gpsPulse {
          0%, 100% { box-shadow: 0 0 0 2px rgba(67,160,71,0.4); }
          50% { box-shadow: 0 0 0 5px rgba(67,160,71,0.1); }
        }
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
