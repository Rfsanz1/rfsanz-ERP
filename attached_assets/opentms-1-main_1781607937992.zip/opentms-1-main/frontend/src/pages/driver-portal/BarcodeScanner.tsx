import React, { useEffect, useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';

interface BarcodeScannerProps {
  onScan: (result: string) => void;
  onClose: () => void;
}

export default function BarcodeScanner({ onScan, onClose }: BarcodeScannerProps) {
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const [status, setStatus] = useState<'starting' | 'scanning' | 'error'>('starting');
  const [errorMsg, setErrorMsg] = useState('');
  const [torchOn, setTorchOn] = useState(false);
  const [scanned, setScanned] = useState(false);
  const elementId = 'qr-reader-container';

  useEffect(() => {
    let scanner: Html5Qrcode;

    async function startScanner() {
      try {
        scanner = new Html5Qrcode(elementId, { verbose: false });
        scannerRef.current = scanner;

        await scanner.start(
          { facingMode: 'environment' },
          {
            fps: 12,
            qrbox: { width: 260, height: 160 },
            aspectRatio: 1.5,
            formatsToSupport: undefined,
          },
          (decodedText) => {
            if (scanned) return;
            setScanned(true);
            // Vibrate on success
            if (navigator.vibrate) navigator.vibrate([80, 40, 80]);
            stopAndCallback(scanner, decodedText);
          },
          () => { /* ignore frequent scan failures */ }
        );
        setStatus('scanning');
      } catch (err: any) {
        setStatus('error');
        setErrorMsg(
          err?.message?.includes('permission')
            ? 'Izin kamera ditolak. Buka pengaturan browser dan izinkan akses kamera.'
            : 'Kamera tidak bisa dibuka. Coba refresh halaman.'
        );
      }
    }

    startScanner();

    return () => {
      if (scannerRef.current) {
        scannerRef.current.stop().catch(() => {});
      }
    };
  }, []);

  async function stopAndCallback(scanner: Html5Qrcode, result: string) {
    try {
      await scanner.stop();
    } catch (_) {}
    onScan(result);
  }

  async function toggleTorch() {
    const scanner = scannerRef.current;
    if (!scanner) return;
    try {
      await (scanner as any).applyVideoConstraints({
        advanced: [{ torch: !torchOn }],
      });
      setTorchOn(t => !t);
    } catch (_) {}
  }

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 2000,
      background: '#000', display: 'flex', flexDirection: 'column',
    }}>
      {/* Top bar */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, zIndex: 10,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '16px',
        background: 'linear-gradient(to bottom, rgba(0,0,0,0.7), transparent)',
      }}>
        <button onClick={onClose} style={{
          background: 'rgba(255,255,255,0.15)', border: 'none',
          borderRadius: 12, padding: '10px 16px', color: '#fff',
          fontSize: 14, fontWeight: 600, cursor: 'pointer',
          display: 'flex', alignItems: 'center', gap: 6,
          backdropFilter: 'blur(8px)',
        }}>
          <span className="material-icons" style={{ fontSize: 18 }}>arrow_back</span>
          Tutup
        </button>
        <div style={{ color: '#fff', fontSize: 15, fontWeight: 700 }}>Scan Kode Paket</div>
        <button onClick={toggleTorch} style={{
          background: torchOn ? 'rgba(255,220,0,0.3)' : 'rgba(255,255,255,0.15)',
          border: 'none', borderRadius: 12, padding: '10px 14px',
          color: torchOn ? '#FFD600' : '#fff', cursor: 'pointer',
          backdropFilter: 'blur(8px)',
        }}>
          <span className="material-icons" style={{ fontSize: 22 }}>
            {torchOn ? 'flashlight_on' : 'flashlight_off'}
          </span>
        </button>
      </div>

      {/* Scanner area */}
      <div style={{ flex: 1, position: 'relative' }}>
        <div
          id={elementId}
          style={{ width: '100%', height: '100%' }}
        />

        {/* Overlay with viewfinder */}
        {status === 'scanning' && (
          <div style={{
            position: 'absolute', inset: 0, pointerEvents: 'none',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            {/* Dark overlay sides */}
            <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.45)' }} />

            {/* Viewfinder box */}
            <div style={{
              position: 'relative', zIndex: 1,
              width: 270, height: 170,
            }}>
              {/* Corner brackets */}
              {[
                { top: 0, left: 0, borderTop: '3px solid #e53935', borderLeft: '3px solid #e53935', borderRadius: '8px 0 0 0' },
                { top: 0, right: 0, borderTop: '3px solid #e53935', borderRight: '3px solid #e53935', borderRadius: '0 8px 0 0' },
                { bottom: 0, left: 0, borderBottom: '3px solid #e53935', borderLeft: '3px solid #e53935', borderRadius: '0 0 0 8px' },
                { bottom: 0, right: 0, borderBottom: '3px solid #e53935', borderRight: '3px solid #e53935', borderRadius: '0 0 8px 0' },
              ].map((s, i) => (
                <div key={i} style={{ position: 'absolute', width: 28, height: 28, ...s }} />
              ))}

              {/* Scan line animation */}
              <div style={{
                position: 'absolute', left: 8, right: 8, height: 2,
                background: 'linear-gradient(to right, transparent, #e53935, transparent)',
                animation: 'scanline 2s ease-in-out infinite',
                borderRadius: 1,
              }} />

              {/* Clear center */}
              <div style={{
                position: 'absolute', inset: 0,
                background: 'transparent',
              }} />
            </div>
          </div>
        )}

        {status === 'starting' && (
          <div style={{
            position: 'absolute', inset: 0,
            display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center', gap: 16,
            background: '#111',
          }}>
            <div style={{
              width: 48, height: 48, borderRadius: 24,
              border: '3px solid #e53935', borderTopColor: 'transparent',
              animation: 'spin 0.8s linear infinite',
            }} />
            <div style={{ color: '#fff', fontSize: 14 }}>Membuka kamera...</div>
          </div>
        )}

        {status === 'error' && (
          <div style={{
            position: 'absolute', inset: 0,
            display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center', gap: 16,
            background: '#111', padding: 32, textAlign: 'center',
          }}>
            <span className="material-icons" style={{ fontSize: 56, color: '#e53935' }}>no_photography</span>
            <div style={{ color: '#fff', fontSize: 14, lineHeight: 1.6 }}>{errorMsg}</div>
            <button onClick={onClose} style={{
              padding: '12px 28px', borderRadius: 12, border: 'none',
              background: '#e53935', color: '#fff', fontSize: 14, fontWeight: 600, cursor: 'pointer',
            }}>Kembali</button>
          </div>
        )}
      </div>

      {/* Bottom hint */}
      {status === 'scanning' && (
        <div style={{
          position: 'absolute', bottom: 0, left: 0, right: 0,
          padding: '24px 32px 40px',
          background: 'linear-gradient(to top, rgba(0,0,0,0.8), transparent)',
          textAlign: 'center',
        }}>
          <p style={{ margin: 0, color: 'rgba(255,255,255,0.8)', fontSize: 13, lineHeight: 1.6 }}>
            Arahkan kamera ke <strong style={{ color: '#fff' }}>barcode</strong> atau <strong style={{ color: '#fff' }}>QR code</strong> pada paket
          </p>
          <div style={{
            marginTop: 12, display: 'flex', alignItems: 'center',
            justifyContent: 'center', gap: 8,
          }}>
            <div style={{
              width: 8, height: 8, borderRadius: 4, background: '#e53935',
              animation: 'pulse 1.5s ease-in-out infinite',
            }} />
            <span style={{ color: 'rgba(255,255,255,0.6)', fontSize: 12 }}>Sedang memindai...</span>
          </div>
        </div>
      )}

      <style>{`
        @keyframes scanline {
          0% { top: 10px; opacity: 1; }
          50% { top: calc(100% - 10px); opacity: 0.8; }
          100% { top: 10px; opacity: 1; }
        }
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(0.8); }
        }
        #${elementId} video { object-fit: cover !important; }
        #${elementId} > div { border: none !important; }
      `}</style>
    </div>
  );
}
