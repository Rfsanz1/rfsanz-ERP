import { useState, useEffect, useRef, useCallback } from 'react';
import { API_URL } from '../../api';

function getDriverToken() { return localStorage.getItem('driver_token') || ''; }

export interface GpsStatus {
  active: boolean;
  error: string;
  lastSent: Date | null;
  coords: { lat: number; lng: number; accuracy: number } | null;
  sending: boolean;
}

const SEND_INTERVAL_MS = 30_000; // kirim setiap 30 detik

export function useGpsTracking(loadId?: string) {
  const [status, setStatus] = useState<GpsStatus>({
    active: false,
    error: '',
    lastSent: null,
    coords: null,
    sending: false,
  });

  const watchIdRef = useRef<number | null>(null);
  const sendTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const latestCoordsRef = useRef<{ lat: number; lng: number; accuracy: number } | null>(null);
  const isActiveRef = useRef(false);

  async function sendLocation(coords: { lat: number; lng: number; accuracy: number }) {
    if (!loadId) return;
    setStatus(s => ({ ...s, sending: true }));
    try {
      await fetch(`${API_URL}/api/v1/driver-portal/loads/${loadId}/location`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${getDriverToken()}`,
        },
        body: JSON.stringify({
          latitude: coords.lat,
          longitude: coords.lng,
          accuracy: coords.accuracy,
          timestamp: new Date().toISOString(),
        }),
      });
      setStatus(s => ({ ...s, lastSent: new Date(), sending: false }));
    } catch {
      setStatus(s => ({ ...s, sending: false }));
    }
  }

  const startTracking = useCallback(() => {
    if (!navigator.geolocation) {
      setStatus(s => ({ ...s, error: 'GPS tidak didukung browser ini' }));
      return;
    }
    isActiveRef.current = true;

    watchIdRef.current = navigator.geolocation.watchPosition(
      (pos) => {
        const coords = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          accuracy: Math.round(pos.coords.accuracy),
        };
        latestCoordsRef.current = coords;
        setStatus(s => ({ ...s, active: true, error: '', coords }));
      },
      (err) => {
        const msg =
          err.code === 1 ? 'Izin GPS ditolak. Aktifkan di pengaturan browser.' :
          err.code === 2 ? 'Posisi GPS tidak tersedia saat ini.' :
          'Waktu mendapat GPS habis. Coba lagi.';
        setStatus(s => ({ ...s, error: msg, active: false }));
        isActiveRef.current = false;
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 5000 }
    );

    // Kirim lokasi tiap interval
    sendTimerRef.current = setInterval(() => {
      if (latestCoordsRef.current && isActiveRef.current) {
        sendLocation(latestCoordsRef.current);
      }
    }, SEND_INTERVAL_MS);

    // Kirim segera saat mulai
    setTimeout(() => {
      if (latestCoordsRef.current) sendLocation(latestCoordsRef.current);
    }, 2000);

    setStatus(s => ({ ...s, active: true, error: '' }));
  }, [loadId]);

  const stopTracking = useCallback(() => {
    isActiveRef.current = false;
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    if (sendTimerRef.current) {
      clearInterval(sendTimerRef.current);
      sendTimerRef.current = null;
    }
    setStatus(s => ({ ...s, active: false }));
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      isActiveRef.current = false;
      if (watchIdRef.current !== null) navigator.geolocation.clearWatch(watchIdRef.current);
      if (sendTimerRef.current) clearInterval(sendTimerRef.current);
    };
  }, []);

  return { status, startTracking, stopTracking };
}
