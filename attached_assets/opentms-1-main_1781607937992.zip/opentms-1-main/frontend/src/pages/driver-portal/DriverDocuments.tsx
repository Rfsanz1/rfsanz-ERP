import React, { useEffect, useState } from 'react';
import { API_URL } from '../../api';

function getDriverToken() { return localStorage.getItem('driver_token') || ''; }

interface Doc {
  id: string;
  fileName?: string;
  documentType?: string;
  url?: string;
  shipmentRef?: string;
  createdAt: string;
}

export default function DriverDocuments() {
  const [docs, setDocs] = useState<Doc[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    async function fetchDocs() {
      try {
        const res = await fetch(`${API_URL}/api/v1/driver-portal/documents`, {
          headers: { Authorization: `Bearer ${getDriverToken()}` },
        });
        const json = await res.json();
        if (!res.ok) throw new Error(json.error || 'Gagal memuat dokumen');
        setDocs(json.data || []);
      } catch (e: any) {
        setError(e.message);
      } finally {
        setLoading(false);
      }
    }
    fetchDocs();
  }, []);

  const typeLabel: Record<string, string> = {
    bill_of_lading: 'Bill of Lading',
    proof_of_delivery: 'Bukti Pengiriman',
    rate_confirmation: 'Rate Confirmation',
    photo: 'Foto',
    other: 'Lainnya',
  };

  const typeIcon: Record<string, string> = {
    bill_of_lading: 'receipt_long',
    proof_of_delivery: 'task_alt',
    rate_confirmation: 'attach_money',
    photo: 'photo_camera',
    other: 'description',
  };

  return (
    <div style={{ padding: '16px 16px 80px' }}>
      <h2 style={{ margin: '0 0 16px', fontSize: 18, fontWeight: 700, color: '#212121' }}>
        Dokumen Saya
      </h2>

      {loading && (
        <div style={{ textAlign: 'center', padding: '40px 0', color: '#9e9e9e' }}>
          <span className="material-icons" style={{ fontSize: 36, display: 'block', marginBottom: 8 }}>hourglass_empty</span>
          Memuat dokumen...
        </div>
      )}

      {error && (
        <div style={{ background: '#ffebee', borderRadius: 12, padding: 16, color: '#b71c1c', fontSize: 13 }}>
          {error}
        </div>
      )}

      {!loading && !error && docs.length === 0 && (
        <div style={{ textAlign: 'center', padding: '60px 0', color: '#9e9e9e' }}>
          <span className="material-icons" style={{ fontSize: 48, display: 'block', marginBottom: 12, color: '#e0e0e0' }}>folder_open</span>
          <div style={{ fontWeight: 500 }}>Belum ada dokumen</div>
          <div style={{ fontSize: 12, marginTop: 4 }}>Dokumen akan muncul setelah pengiriman selesai</div>
        </div>
      )}

      {docs.map(doc => {
        const icon = typeIcon[doc.documentType || ''] || 'description';
        const label = typeLabel[doc.documentType || ''] || doc.documentType || 'Dokumen';
        return (
          <div key={doc.id} style={{
            background: '#fff', borderRadius: 14, padding: '14px 16px',
            marginBottom: 12, boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
            display: 'flex', alignItems: 'center', gap: 14,
          }}>
            <div style={{
              width: 44, height: 44, borderRadius: 12,
              background: '#e3f2fd', display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <span className="material-icons" style={{ color: '#1976d2', fontSize: 22 }}>{icon}</span>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: '#212121' }}>{label}</div>
              {doc.shipmentRef && (
                <div style={{ fontSize: 11, color: '#9e9e9e', marginTop: 2 }}>{doc.shipmentRef}</div>
              )}
              <div style={{ fontSize: 11, color: '#bdbdbd', marginTop: 2 }}>
                {new Date(doc.createdAt).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}
              </div>
            </div>
            {doc.url && (
              <a
                href={doc.url}
                target="_blank"
                rel="noreferrer"
                style={{
                  width: 36, height: 36, borderRadius: 8,
                  background: '#f5f5f5', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  color: '#1976d2', textDecoration: 'none',
                }}
              >
                <span className="material-icons" style={{ fontSize: 18 }}>download</span>
              </a>
            )}
          </div>
        );
      })}
    </div>
  );
}
