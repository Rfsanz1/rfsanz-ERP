import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { API_URL } from '../../api';
import BarcodeScanner from './BarcodeScanner';

function getDriverToken() { return localStorage.getItem('driver_token') || ''; }
function getDriverUser() {
  try { return JSON.parse(localStorage.getItem('driver_user') || '{}'); } catch { return {}; }
}

interface Load {
  id: string;
  shipmentId: string;
  shipment?: {
    referenceNumber?: string;
    status: string;
    originCity?: string;
    originState?: string;
    originAddress?: string;
    destinationCity?: string;
    destinationState?: string;
    destinationAddress?: string;
    scheduledPickup?: string;
    scheduledDelivery?: string;
    customerName?: string;
    customerPhone?: string;
    totalWeight?: number;
    stops?: Array<{
      id: string;
      type: string;
      locationName?: string;
      address?: string;
      city?: string;
      state?: string;
      status: string;
      contactName?: string;
      contactPhone?: string;
    }>;
  };
}

const STATUS_MAP: Record<string, { label: string; color: string; bg: string; icon: string }> = {
  booked:     { label: 'Menunggu', color: '#1565c0', bg: '#e3f2fd', icon: 'schedule' },
  pickup:     { label: 'Menuju Pickup', color: '#e65100', bg: '#fff3e0', icon: 'directions_car' },
  picked_up:  { label: 'Barang Diambil', color: '#7b1fa2', bg: '#f3e5f5', icon: 'inventory_2' },
  in_transit: { label: 'Dalam Perjalanan', color: '#1b5e20', bg: '#e8f5e9', icon: 'local_shipping' },
  delivered:  { label: 'Terkirim', color: '#2e7d32', bg: '#c8e6c9', icon: 'check_circle' },
  cancelled:  { label: 'Dibatalkan', color: '#b71c1c', bg: '#ffebee', icon: 'cancel' },
};

function openMaps(address: string, city?: string) {
  const query = encodeURIComponent([address, city].filter(Boolean).join(', '));
  window.open(`https://maps.google.com/maps?q=${query}`, '_blank');
}

export default function DriverDashboard() {
  const navigate = useNavigate();
  const driver = getDriverUser();
  const [loads, setLoads] = useState<Load[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [tab, setTab] = useState<'active' | 'done'>('active');
  const [showScanner, setShowScanner] = useState(false);
  const [scanResult, setScanResult] = useState<{ code: string; found: boolean; loadId?: string } | null>(null);

  useEffect(() => {
    async function fetchLoads() {
      try {
        const res = await fetch(`${API_URL}/api/v1/driver-portal/my-loads`, {
          headers: { Authorization: `Bearer ${getDriverToken()}` },
        });
        if (!res.ok) throw new Error('Gagal memuat tugas');
        const json = await res.json();
        setLoads(json.data || []);
      } catch (e: any) {
        setError(e.message);
      } finally {
        setLoading(false);
      }
    }
    fetchLoads();
  }, []);

  const active = loads.filter(l => l.shipment && !['delivered', 'cancelled'].includes(l.shipment.status));
  const done = loads.filter(l => l.shipment && ['delivered', 'cancelled'].includes(l.shipment.status));
  const shown = tab === 'active' ? active : done;

  const greetHour = new Date().getHours();
  const greet = greetHour < 11 ? 'Selamat pagi' : greetHour < 15 ? 'Selamat siang' : greetHour < 18 ? 'Selamat sore' : 'Selamat malam';

  function handleScan(code: string) {
    setShowScanner(false);
    const cleaned = code.trim();
    // Match against referenceNumber or load id
    const matched = loads.find(l =>
      l.id === cleaned ||
      l.shipmentId === cleaned ||
      (l.shipment?.referenceNumber || '').toLowerCase() === cleaned.toLowerCase() ||
      cleaned.toLowerCase().includes((l.shipment?.referenceNumber || '').toLowerCase())
    );
    if (matched) {
      setScanResult({ code: cleaned, found: true, loadId: matched.id });
    } else {
      setScanResult({ code: cleaned, found: false });
    }
  }

  return (
    <div style={{ paddingBottom: 80, background: '#f4f6f8', minHeight: '100vh' }}>
      {/* Hero header */}
      <div style={{
        background: 'linear-gradient(135deg, #c62828, #e53935)',
        padding: '20px 16px 56px',
        color: '#fff',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <p style={{ margin: '0 0 2px', fontSize: 12, opacity: 0.8 }}>{greet},</p>
            <h1 style={{ margin: '0 0 4px', fontSize: 20, fontWeight: 700 }}>{driver.name || 'Driver'}</h1>
            {driver.phone && (
              <p style={{ margin: 0, fontSize: 12, opacity: 0.7 }}>{driver.phone}</p>
            )}
          </div>
          <div style={{
            width: 44, height: 44, borderRadius: 22,
            background: 'rgba(255,255,255,0.2)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <span className="material-icons" style={{ fontSize: 24 }}>person</span>
          </div>
        </div>
      </div>

      {/* Stats cards */}
      <div style={{
        display: 'grid', gridTemplateColumns: '1fr 1fr 1fr',
        gap: 10, padding: '0 16px',
        marginTop: -36,
      }}>
        {[
          { icon: 'local_shipping', label: 'Aktif', value: active.length, color: '#e53935' },
          { icon: 'check_circle', label: 'Selesai', value: done.length, color: '#43a047' },
          { icon: 'assignment', label: 'Total', value: loads.length, color: '#1976d2' },
        ].map(item => (
          <div key={item.label} style={{
            background: '#fff', borderRadius: 16, padding: '14px 12px',
            boxShadow: '0 4px 16px rgba(0,0,0,0.1)',
            textAlign: 'center',
          }}>
            <div style={{
              width: 36, height: 36, borderRadius: 10,
              background: item.color + '18',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              margin: '0 auto 6px',
            }}>
              <span className="material-icons" style={{ color: item.color, fontSize: 20 }}>{item.icon}</span>
            </div>
            <div style={{ fontSize: 22, fontWeight: 700, lineHeight: 1, color: '#212121' }}>{item.value}</div>
            <div style={{ fontSize: 11, color: '#9e9e9e', marginTop: 2 }}>{item.label}</div>
          </div>
        ))}
      </div>

      {/* Tab bar */}
      <div style={{
        display: 'flex', margin: '16px 16px 0',
        background: '#fff', borderRadius: 14,
        padding: 4, gap: 4,
        boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
      }}>
        {([['active', 'Tugas Aktif', active.length], ['done', 'Riwayat', done.length]] as const).map(([key, label, count]) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            style={{
              flex: 1, padding: '10px 8px', border: 'none', borderRadius: 10,
              background: tab === key ? '#e53935' : 'transparent',
              color: tab === key ? '#fff' : '#757575',
              fontWeight: tab === key ? 600 : 400,
              fontSize: 13, cursor: 'pointer',
              transition: 'all 0.2s',
            }}
          >
            {label} {count > 0 && (
              <span style={{
                display: 'inline-block', minWidth: 18, height: 18,
                background: tab === key ? 'rgba(255,255,255,0.3)' : '#f0f0f0',
                color: tab === key ? '#fff' : '#757575',
                borderRadius: 9, fontSize: 11, fontWeight: 700,
                textAlign: 'center', lineHeight: '18px', marginLeft: 4,
              }}>{count}</span>
            )}
          </button>
        ))}
      </div>

      {/* List */}
      <div style={{ padding: '12px 16px 0' }}>
        {loading && (
          <div style={{ textAlign: 'center', padding: '48px 0', color: '#9e9e9e' }}>
            <div style={{
              width: 48, height: 48, borderRadius: 24,
              border: '3px solid #e53935', borderTopColor: 'transparent',
              margin: '0 auto 12px', animation: 'spin 0.8s linear infinite',
            }} />
            <div style={{ fontSize: 13 }}>Memuat pengiriman...</div>
          </div>
        )}

        {error && (
          <div style={{
            background: '#ffebee', borderRadius: 14, padding: 16,
            color: '#b71c1c', fontSize: 13, textAlign: 'center',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          }}>
            <span className="material-icons" style={{ fontSize: 20 }}>wifi_off</span>
            {error}
          </div>
        )}

        {!loading && !error && shown.length === 0 && (
          <div style={{ textAlign: 'center', padding: '56px 0', color: '#bdbdbd' }}>
            <span className="material-icons" style={{ fontSize: 56, display: 'block', marginBottom: 12 }}>
              {tab === 'active' ? 'inbox' : 'history'}
            </span>
            <div style={{ fontSize: 14, fontWeight: 500, color: '#9e9e9e' }}>
              {tab === 'active' ? 'Tidak ada tugas aktif' : 'Belum ada riwayat'}
            </div>
          </div>
        )}

        {shown.map(load => {
          const s = load.shipment!;
          const chip = STATUS_MAP[s.status] || { label: s.status, color: '#757575', bg: '#f5f5f5', icon: 'help' };
          const dest = [s.destinationCity, s.destinationState].filter(Boolean).join(', ') || 'N/A';
          const origin = [s.originCity, s.originState].filter(Boolean).join(', ') || 'N/A';
          const isActive = !['delivered', 'cancelled'].includes(s.status);

          return (
            <div key={load.id} style={{
              background: '#fff', borderRadius: 18, marginBottom: 12,
              boxShadow: '0 2px 12px rgba(0,0,0,0.08)',
              overflow: 'hidden',
              border: isActive ? `1px solid ${chip.color}22` : '1px solid #f0f0f0',
            }}>
              {/* Card top */}
              <div
                onClick={() => navigate(`/driver/task/${load.id}`)}
                style={{ padding: '14px 16px', cursor: 'pointer' }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <div style={{
                      width: 32, height: 32, borderRadius: 10,
                      background: chip.color + '18',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}>
                      <span className="material-icons" style={{ color: chip.color, fontSize: 18 }}>{chip.icon}</span>
                    </div>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 700, color: '#212121' }}>
                        {s.referenceNumber || `SHP-${load.shipmentId.slice(0, 8).toUpperCase()}`}
                      </div>
                      {s.scheduledDelivery && (
                        <div style={{ fontSize: 11, color: '#9e9e9e' }}>
                          Estimasi: {new Date(s.scheduledDelivery).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                        </div>
                      )}
                    </div>
                  </div>
                  <span style={{
                    padding: '5px 12px', borderRadius: 100, fontSize: 11, fontWeight: 600,
                    color: chip.color, background: chip.bg,
                  }}>{chip.label}</span>
                </div>

                {/* Route */}
                <div style={{ display: 'flex', gap: 10, alignItems: 'stretch' }}>
                  {/* Timeline */}
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', paddingTop: 4 }}>
                    <div style={{ width: 10, height: 10, borderRadius: 5, background: '#f57c00', flexShrink: 0 }} />
                    <div style={{ width: 2, flex: 1, background: '#e0e0e0', margin: '3px 0' }} />
                    <div style={{ width: 10, height: 10, borderRadius: 5, background: '#1976d2', flexShrink: 0 }} />
                  </div>
                  {/* Addresses */}
                  <div style={{ flex: 1 }}>
                    <div style={{ marginBottom: 10 }}>
                      <div style={{ fontSize: 11, color: '#f57c00', fontWeight: 600, marginBottom: 1 }}>PICKUP</div>
                      <div style={{ fontSize: 13, fontWeight: 500, color: '#424242' }}>{origin}</div>
                      {s.originAddress && <div style={{ fontSize: 11, color: '#9e9e9e', marginTop: 1 }}>{s.originAddress}</div>}
                    </div>
                    <div>
                      <div style={{ fontSize: 11, color: '#1976d2', fontWeight: 600, marginBottom: 1 }}>TUJUAN</div>
                      <div style={{ fontSize: 13, fontWeight: 500, color: '#424242' }}>{dest}</div>
                      {s.destinationAddress && <div style={{ fontSize: 11, color: '#9e9e9e', marginTop: 1 }}>{s.destinationAddress}</div>}
                    </div>
                  </div>
                </div>

                {s.customerName && (
                  <div style={{
                    marginTop: 12, padding: '8px 12px',
                    background: '#f8f9fa', borderRadius: 10,
                    display: 'flex', alignItems: 'center', gap: 8, fontSize: 12,
                  }}>
                    <span className="material-icons" style={{ fontSize: 16, color: '#9e9e9e' }}>person</span>
                    <span style={{ color: '#424242', fontWeight: 500 }}>{s.customerName}</span>
                    {s.customerPhone && <span style={{ color: '#9e9e9e' }}>• {s.customerPhone}</span>}
                  </div>
                )}
              </div>

              {/* Action buttons */}
              {isActive && (
                <div style={{
                  display: 'flex', borderTop: '1px solid #f5f5f5',
                }}>
                  <button
                    onClick={() => openMaps(s.destinationAddress || dest, s.destinationCity)}
                    style={{
                      flex: 1, padding: '11px 0', border: 'none', background: '#f8f9fa',
                      color: '#1976d2', fontSize: 13, fontWeight: 600, cursor: 'pointer',
                      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                      borderRight: '1px solid #f0f0f0',
                    }}
                  >
                    <span className="material-icons" style={{ fontSize: 18 }}>navigation</span>
                    Navigasi
                  </button>
                  <button
                    onClick={() => navigate(`/driver/task/${load.id}`)}
                    style={{
                      flex: 1, padding: '11px 0', border: 'none', background: '#f8f9fa',
                      color: '#e53935', fontSize: 13, fontWeight: 600, cursor: 'pointer',
                      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                    }}
                  >
                    <span className="material-icons" style={{ fontSize: 18 }}>open_in_new</span>
                    Detail
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* FAB Scan Button */}
      <button
        onClick={() => setShowScanner(true)}
        style={{
          position: 'fixed',
          bottom: 80, right: 16,
          width: 58, height: 58, borderRadius: 29,
          background: 'linear-gradient(135deg, #c62828, #e53935)',
          border: 'none', cursor: 'pointer',
          boxShadow: '0 6px 20px rgba(229,57,53,0.45)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          zIndex: 100, transition: 'transform 0.15s',
        }}
        onTouchStart={e => (e.currentTarget.style.transform = 'scale(0.92)')}
        onTouchEnd={e => (e.currentTarget.style.transform = 'scale(1)')}
      >
        <span className="material-icons" style={{ color: '#fff', fontSize: 26 }}>qr_code_scanner</span>
      </button>

      {/* Scanner Overlay */}
      {showScanner && (
        <BarcodeScanner
          onScan={handleScan}
          onClose={() => setShowScanner(false)}
        />
      )}

      {/* Scan Result Modal */}
      {scanResult && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.55)',
          display: 'flex', alignItems: 'flex-end', zIndex: 1500,
        }} onClick={() => setScanResult(null)}>
          <div style={{
            width: '100%', maxWidth: 480, margin: '0 auto',
            background: '#fff', borderRadius: '24px 24px 0 0',
            padding: '20px 20px 40px',
          }} onClick={e => e.stopPropagation()}>
            <div style={{ width: 40, height: 4, borderRadius: 2, background: '#e0e0e0', margin: '0 auto 20px' }} />

            {scanResult.found ? (
              <>
                <div style={{ textAlign: 'center', marginBottom: 20 }}>
                  <div style={{
                    width: 64, height: 64, borderRadius: 32,
                    background: '#e8f5e9', margin: '0 auto 12px',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    <span className="material-icons" style={{ fontSize: 34, color: '#43a047' }}>check_circle</span>
                  </div>
                  <div style={{ fontSize: 17, fontWeight: 700, color: '#212121' }}>Paket Ditemukan!</div>
                  <div style={{ fontSize: 12, color: '#9e9e9e', fontFamily: 'monospace', background: '#f5f5f5', padding: '6px 12px', borderRadius: 8, display: 'inline-block', marginTop: 8, wordBreak: 'break-all' }}>
                    {scanResult.code}
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 10 }}>
                  <button onClick={() => setScanResult(null)} style={{
                    flex: 1, padding: '14px', borderRadius: 14,
                    border: '1.5px solid #e0e0e0', background: '#fff',
                    color: '#757575', fontSize: 14, cursor: 'pointer',
                  }}>
                    Tutup
                  </button>
                  <button onClick={() => { setScanResult(null); navigate(`/driver/task/${scanResult.loadId}`); }} style={{
                    flex: 2, padding: '14px', borderRadius: 14,
                    border: 'none', background: 'linear-gradient(135deg, #c62828, #e53935)',
                    color: '#fff', fontSize: 14, fontWeight: 700, cursor: 'pointer',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                    boxShadow: '0 4px 14px rgba(229,57,53,0.35)',
                  }}>
                    <span className="material-icons" style={{ fontSize: 20 }}>open_in_new</span>
                    Buka Detail
                  </button>
                </div>
              </>
            ) : (
              <>
                <div style={{ textAlign: 'center', marginBottom: 20 }}>
                  <div style={{
                    width: 64, height: 64, borderRadius: 32,
                    background: '#fff3e0', margin: '0 auto 12px',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    <span className="material-icons" style={{ fontSize: 34, color: '#f57c00' }}>search_off</span>
                  </div>
                  <div style={{ fontSize: 17, fontWeight: 700, color: '#212121' }}>Paket Tidak Ditemukan</div>
                  <div style={{ fontSize: 13, color: '#757575', marginTop: 6, lineHeight: 1.5 }}>
                    Kode ini tidak cocok dengan tugas Anda saat ini.
                  </div>
                  <div style={{ fontSize: 12, color: '#9e9e9e', marginTop: 8, fontFamily: 'monospace', background: '#f5f5f5', padding: '6px 12px', borderRadius: 8, display: 'inline-block', wordBreak: 'break-all' }}>
                    {scanResult.code}
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 10 }}>
                  <button onClick={() => setScanResult(null)} style={{
                    flex: 1, padding: '14px', borderRadius: 14,
                    border: '1.5px solid #e0e0e0', background: '#fff',
                    color: '#757575', fontSize: 14, cursor: 'pointer',
                  }}>
                    Tutup
                  </button>
                  <button onClick={() => { setScanResult(null); setShowScanner(true); }} style={{
                    flex: 1, padding: '14px', borderRadius: 14,
                    border: 'none', background: '#212121',
                    color: '#fff', fontSize: 14, fontWeight: 700, cursor: 'pointer',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                  }}>
                    <span className="material-icons" style={{ fontSize: 20 }}>qr_code_scanner</span>
                    Scan Lagi
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
