import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { API_URL } from '../../api';

function getDriverToken() { return localStorage.getItem('driver_token') || ''; }
function getDriverUser() {
  try { return JSON.parse(localStorage.getItem('driver_user') || '{}'); } catch { return {}; }
}

export default function DriverProfile() {
  const navigate = useNavigate();
  const driver = getDriverUser();
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [error, setError] = useState('');

  async function handleChangePassword(e: React.FormEvent) {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setError('Password baru tidak cocok');
      return;
    }
    if (newPassword.length < 6) {
      setError('Password minimal 6 karakter');
      return;
    }
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`${API_URL}/api/v1/driver-portal/change-password`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${getDriverToken()}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ oldPassword, newPassword }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Gagal mengubah password');
      setSuccessMsg('Password berhasil diubah!');
      setOldPassword(''); setNewPassword(''); setConfirmPassword('');
      setTimeout(() => setSuccessMsg(''), 3000);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  function handleLogout() {
    localStorage.removeItem('driver_token');
    localStorage.removeItem('driver_user');
    navigate('/driver/login');
  }

  const initials = (driver.name || 'D').split(' ').map((n: string) => n[0]).slice(0, 2).join('').toUpperCase();

  return (
    <div style={{ padding: '16px 16px 80px' }}>
      <div style={{
        background: '#fff', borderRadius: 16, padding: 20,
        boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
        display: 'flex', alignItems: 'center', gap: 16, marginBottom: 16,
      }}>
        <div style={{
          width: 60, height: 60, borderRadius: 999,
          background: 'linear-gradient(135deg, #e53935, #b71c1c)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 22, fontWeight: 700, color: '#fff', flexShrink: 0,
        }}>
          {initials}
        </div>
        <div>
          <div style={{ fontSize: 17, fontWeight: 700, color: '#212121' }}>{driver.name || 'Driver'}</div>
          <div style={{ fontSize: 13, color: '#9e9e9e', marginTop: 2 }}>{driver.phone || driver.email || ''}</div>
          {driver.carrierName && (
            <div style={{
              fontSize: 11, marginTop: 6, padding: '2px 8px', borderRadius: 100,
              background: '#e3f2fd', color: '#1565c0', fontWeight: 500, display: 'inline-block',
            }}>
              {driver.carrierName}
            </div>
          )}
        </div>
      </div>

      <div style={{ background: '#fff', borderRadius: 16, padding: 20, boxShadow: '0 2px 8px rgba(0,0,0,0.06)', marginBottom: 16 }}>
        <h3 style={{ margin: '0 0 16px', fontSize: 15, fontWeight: 600 }}>Ubah Password</h3>

        {successMsg && (
          <div style={{ background: '#e8f5e9', borderRadius: 10, padding: '10px 14px', color: '#2e7d32', fontSize: 13, marginBottom: 14, display: 'flex', alignItems: 'center', gap: 8 }}>
            <span className="material-icons" style={{ fontSize: 16 }}>check_circle</span>
            {successMsg}
          </div>
        )}
        {error && (
          <div style={{ background: '#ffebee', borderRadius: 10, padding: '10px 14px', color: '#b71c1c', fontSize: 13, marginBottom: 14 }}>
            {error}
          </div>
        )}

        <form onSubmit={handleChangePassword}>
          {[
            { label: 'Password Lama', value: oldPassword, onChange: setOldPassword, placeholder: 'Masukkan password lama' },
            { label: 'Password Baru', value: newPassword, onChange: setNewPassword, placeholder: 'Min. 6 karakter' },
            { label: 'Konfirmasi Password Baru', value: confirmPassword, onChange: setConfirmPassword, placeholder: 'Ulangi password baru' },
          ].map(field => (
            <div key={field.label} style={{ marginBottom: 14 }}>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 600, color: '#424242', marginBottom: 6 }}>
                {field.label}
              </label>
              <input
                type="password"
                value={field.value}
                onChange={e => field.onChange(e.target.value)}
                placeholder={field.placeholder}
                required
                style={{
                  width: '100%', padding: '11px 14px', borderRadius: 10,
                  border: '1.5px solid #e0e0e0', fontSize: 14,
                  outline: 'none', boxSizing: 'border-box',
                }}
              />
            </div>
          ))}
          <button
            type="submit"
            disabled={loading}
            style={{
              width: '100%', padding: '13px', borderRadius: 10,
              background: loading ? '#bdbdbd' : '#1976d2',
              color: '#fff', border: 'none', fontSize: 14, fontWeight: 600,
              cursor: loading ? 'not-allowed' : 'pointer',
            }}
          >
            {loading ? 'Menyimpan...' : 'Ubah Password'}
          </button>
        </form>
      </div>

      <div style={{ background: '#fff', borderRadius: 16, padding: 20, boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}>
        <h3 style={{ margin: '0 0 14px', fontSize: 15, fontWeight: 600 }}>Informasi Akun</h3>
        {[
          { label: 'Nama', value: driver.name },
          { label: 'Telepon', value: driver.phone },
          { label: 'Email', value: driver.email },
          { label: 'Perusahaan', value: driver.carrierName },
        ].filter(r => r.value).map(row => (
          <div key={row.label} style={{
            display: 'flex', justifyContent: 'space-between',
            padding: '10px 0', borderBottom: '1px solid #f5f5f5', fontSize: 13,
          }}>
            <span style={{ color: '#9e9e9e' }}>{row.label}</span>
            <span style={{ fontWeight: 500, color: '#212121' }}>{row.value}</span>
          </div>
        ))}
      </div>

      <button
        onClick={handleLogout}
        style={{
          width: '100%', marginTop: 20, padding: '14px', borderRadius: 12,
          background: '#ffebee', border: '1.5px solid #ef9a9a',
          color: '#b71c1c', fontSize: 15, fontWeight: 600, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
        }}
      >
        <span className="material-icons">logout</span>
        Keluar
      </button>
    </div>
  );
}
