import React, { useEffect, useState } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import './theme.css';

function getDriverUser() {
  try { return JSON.parse(localStorage.getItem('driver_user') || '{}'); } catch { return {}; }
}

function useGpsIndicator() {
  const [hasGps, setHasGps] = useState(false);
  useEffect(() => {
    if (!navigator.geolocation) return;
    const id = navigator.geolocation.watchPosition(
      () => setHasGps(true),
      () => setHasGps(false),
      { enableHighAccuracy: true, timeout: 10000 }
    );
    return () => navigator.geolocation.clearWatch(id);
  }, []);
  return hasGps;
}

export function DriverPortalLayout() {
  const driver = getDriverUser();
  const location = useLocation();
  const hasGps = useGpsIndicator();

  // Hide bottom nav on task detail page (full-screen experience)
  const isTaskDetail = location.pathname.startsWith('/driver/task/');

  const NAV = [
    { to: '/driver', icon: 'home', label: 'Beranda', end: true },
    { to: '/driver/documents', icon: 'folder', label: 'Dokumen', end: false },
    { to: '/driver/report', icon: 'bar_chart', label: 'Laporan', end: false },
    { to: '/driver/profile', icon: 'person', label: 'Profil', end: false },
  ];

  return (
    <div style={{ minHeight: '100vh', background: '#f5f5f5', fontFamily: 'Inter, Roboto, sans-serif', maxWidth: 480, margin: '0 auto', position: 'relative' }}>
      {/* Top header */}
      <div style={{
        position: 'sticky', top: 0, zIndex: 100,
        background: '#fff',
        boxShadow: '0 1px 4px rgba(0,0,0,0.08)',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '0 16px', height: 52,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{
            width: 28, height: 28, borderRadius: 6,
            background: 'linear-gradient(135deg, #e53935, #b71c1c)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <span className="material-icons" style={{ color: '#fff', fontSize: 16 }}>local_shipping</span>
          </div>
          <span style={{ fontWeight: 700, fontSize: 15, color: '#212121' }}>Driver Portal</span>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          {/* GPS indicator */}
          <div style={{
            display: 'flex', alignItems: 'center', gap: 5,
            background: hasGps ? '#e8f5e9' : '#f5f5f5',
            padding: '4px 10px', borderRadius: 20,
          }}>
            <div style={{
              width: 7, height: 7, borderRadius: 4,
              background: hasGps ? '#43a047' : '#bdbdbd',
              animation: hasGps ? 'gpsPulse 2s ease-in-out infinite' : 'none',
            }} />
            <span className="material-icons" style={{
              fontSize: 14, color: hasGps ? '#43a047' : '#bdbdbd',
            }}>gps_fixed</span>
            <span style={{ fontSize: 11, fontWeight: 600, color: hasGps ? '#43a047' : '#9e9e9e' }}>
              {hasGps ? 'GPS' : 'No GPS'}
            </span>
          </div>
          {driver.name && (
            <span style={{ fontSize: 13, color: '#9e9e9e' }}>{driver.name}</span>
          )}
        </div>
      </div>

      {/* Page content */}
      <div style={{ paddingBottom: isTaskDetail ? 0 : 64 }}>
        <Outlet />
      </div>

      {/* Bottom navigation — hidden on task detail */}
      {!isTaskDetail && (
        <nav style={{
          position: 'fixed', bottom: 0, left: '50%', transform: 'translateX(-50%)',
          width: '100%', maxWidth: 480,
          background: '#fff', borderTop: '1px solid #f0f0f0',
          display: 'flex', height: 64,
          boxShadow: '0 -2px 12px rgba(0,0,0,0.08)',
          zIndex: 100,
        }}>
          {NAV.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              style={({ isActive }) => ({
                flex: 1, display: 'flex', flexDirection: 'column' as const,
                alignItems: 'center', justifyContent: 'center',
                gap: 2, textDecoration: 'none', padding: '8px 0',
                color: isActive ? '#e53935' : '#9e9e9e',
                transition: 'color 0.15s',
              })}
            >
              {({ isActive }) => (
                <>
                  <span className="material-icons" style={{ fontSize: 22 }}>{item.icon}</span>
                  <span style={{ fontSize: 10, fontWeight: isActive ? 600 : 400 }}>{item.label}</span>
                </>
              )}
            </NavLink>
          ))}
        </nav>
      )}

      <style>{`
        @keyframes gpsPulse {
          0%, 100% { box-shadow: 0 0 0 2px rgba(67,160,71,0.3); }
          50% { box-shadow: 0 0 0 5px rgba(67,160,71,0.08); }
        }
      `}</style>
    </div>
  );
}
