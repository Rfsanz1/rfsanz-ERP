import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// URL backend kamu (CasaOS atau server lain).
// Set env var VITE_API_URL di Replit = http://IP_CASAOS:3000
const backendUrl = process.env.VITE_API_URL || 'http://localhost:3000';

export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: parseInt(process.env.VITE_PORT || '5000'),
    strictPort: false,
    allowedHosts: true,
    proxy: {
      '/api': {
        target: backendUrl,
        changeOrigin: true,
        secure: false,
      }
    }
  },
  define: {
    'import.meta.env.VITE_API_URL': JSON.stringify('')
  }
})
