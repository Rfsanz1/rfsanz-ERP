# TMS Dashboard Component

Komponen React standalone untuk embed di ERP atau aplikasi lain.

## Cara Pakai

### 1. Copy file ini ke project ERP Anda
Salin file `src/TmsDashboard.tsx` ke project React Anda.

### 2. Gunakan komponen
```tsx
import { TmsDashboard } from './TmsDashboard';

function MyErpPage() {
  return (
    <TmsDashboard
      apiUrl="https://briskly-underpaid-shucking.ngrok-free.dev"
      authToken={myAuthToken}
      onNavigate={(path) => {
        // handle navigasi sesuai ERP Anda
        console.log('Navigate to:', path);
      }}
    />
  );
}
```

## Props

| Prop | Type | Wajib | Keterangan |
|------|------|-------|------------|
| `apiUrl` | string | ✅ | URL backend TMS |
| `authToken` | string | ✅ | JWT token dari login TMS |
| `onNavigate` | function | ❌ | Callback saat user klik link navigasi |

## Fitur Dashboard
- Statistik aktif: shipment aktif, order pending, in transit, terkirim, on-time rate
- Tabel shipment terbaru
- Daftar isu aktif
- Panel SLA Health
- Bar performa pengiriman

## Tidak memerlukan dependency tambahan
Komponen ini hanya butuh React. Tidak ada CSS eksternal — semua styling inline.
