import React, { useEffect, useState } from 'react';

interface TmsDashboardProps {
  apiUrl: string;
  authToken: string;
  onNavigate?: (path: string) => void;
}

interface Shipment {
  id: string;
  referenceNumber?: string;
  status: string;
  originCity?: string;
  originState?: string;
  destinationCity?: string;
  destinationState?: string;
}

interface Order {
  id: string;
  status: string;
}

interface Issue {
  id: string;
  title: string;
  priority: string;
  status: string;
  createdAt: string;
  sourceEntityId?: string;
}

interface SlaSummary {
  active: number;
  warning: number;
  breached: number;
  met: number;
  total: number;
}

export function TmsDashboard({ apiUrl, authToken, onNavigate }: TmsDashboardProps) {
  const [shipments, setShipments] = useState<Shipment[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [activeIssues, setActiveIssues] = useState<Issue[]>([]);
  const [slaSummary, setSlaSummary] = useState<SlaSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const headers = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${authToken}`,
  };

  useEffect(() => {
    let cancelled = false;
    async function fetchData() {
      try {
        const [shipRes, ordRes] = await Promise.all([
          fetch(`${apiUrl}/api/v1/shipments`, { headers }),
          fetch(`${apiUrl}/api/v1/orders`, { headers }),
        ]);
        if (!shipRes.ok) throw new Error('Gagal memuat data shipment');
        if (!ordRes.ok) throw new Error('Gagal memuat data order');
        const shipJson = await shipRes.json();
        const ordJson = await ordRes.json();
        if (!cancelled) {
          setShipments(shipJson.data || []);
          setOrders(ordJson.data || []);
        }
        fetch(`${apiUrl}/api/v1/issues`, { headers })
          .then(r => r.json())
          .then(json => {
            if (!cancelled) {
              const issues = (json.data || [])
                .filter((i: Issue) => i.status === 'open' || i.status === 'in_progress')
                .slice(0, 5);
              setActiveIssues(issues);
            }
          }).catch(() => {});
        fetch(`${apiUrl}/api/v1/sla/evaluations/summary`, { headers })
          .then(r => r.json())
          .then(json => { if (!cancelled) setSlaSummary(json.data || null); })
          .catch(() => {});
      } catch (e: any) {
        if (!cancelled) setError(e.message || 'Gagal memuat data');
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    fetchData();
    return () => { cancelled = true; };
  }, [apiUrl, authToken]);

  const nav = (path: string) => onNavigate?.(path);

  const activeShipments = shipments.filter(s => s.status !== 'delivered' && s.status !== 'cancelled');
  const inTransit = shipments.filter(s => s.status === 'in_transit');
  const delivered = shipments.filter(s => s.status === 'delivered');
  const pendingOrders = orders.filter(o => o.status === 'pending' || o.status === 'new');
  const recentShipments = shipments.slice(0, 5);
  const total = shipments.length || 1;
  const onTimeRate = ((delivered.length / total) * 100).toFixed(1);

  const statusChip = (status: string) => {
    const map: Record<string, { label: string; color: string }> = {
      in_transit: { label: 'Dalam Perjalanan', color: '#1976d2' },
      delivered: { label: 'Terkirim', color: '#388e3c' },
      pickup: { label: 'Pickup', color: '#f57c00' },
      picked_up: { label: 'Pickup', color: '#f57c00' },
      booked: { label: 'Booked', color: '#757575' },
    };
    return map[status] || { label: status || 'Unknown', color: '#757575' };
  };

  const severityColor = (p: string) => {
    if (p === 'critical' || p === 'high') return '#c62828';
    if (p === 'medium') return '#f57c00';
    return '#1976d2';
  };

  const relTime = (dateStr: string) => {
    if (!dateStr) return '';
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return `${mins}m lalu`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}j lalu`;
    return `${Math.floor(hrs / 24)}h lalu`;
  };

  const s: Record<string, React.CSSProperties> = {
    wrap: { fontFamily: 'Inter, Roboto, sans-serif', background: '#f5f5f5', padding: 24, minHeight: '100vh', color: '#212121' },
    header: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 },
    h1: { margin: 0, fontSize: 24, fontWeight: 700 },
    sub: { margin: '4px 0 0', color: '#757575', fontSize: 14 },
    stats: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 16, marginBottom: 24 },
    stat: { background: '#fff', borderRadius: 12, padding: 20, display: 'flex', alignItems: 'center', gap: 14, boxShadow: '0 1px 3px rgba(0,0,0,0.08)', cursor: 'pointer' },
    icon: (color: string): React.CSSProperties => ({ width: 44, height: 44, borderRadius: 10, background: color + '1a', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, color }),
    val: { fontSize: 28, fontWeight: 700, lineHeight: 1 },
    label: { fontSize: 12, color: '#757575', marginTop: 4 },
    grid2: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: 16, marginBottom: 16 },
    card: { background: '#fff', borderRadius: 12, boxShadow: '0 1px 3px rgba(0,0,0,0.08)', overflow: 'hidden' },
    cardHead: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px 20px', borderBottom: '1px solid #f0f0f0' },
    cardTitle: { margin: 0, fontSize: 15, fontWeight: 600 },
    cardBody: { padding: 0 },
    table: { width: '100%', borderCollapse: 'collapse' as const },
    th: { padding: '10px 16px', fontSize: 12, fontWeight: 600, color: '#757575', textAlign: 'left' as const, borderBottom: '1px solid #f5f5f5' },
    td: { padding: '12px 16px', fontSize: 13, borderBottom: '1px solid #fafafa' },
    chip: (color: string): React.CSSProperties => ({ display: 'inline-block', padding: '3px 8px', borderRadius: 100, fontSize: 11, fontWeight: 600, color, background: color + '18' }),
    issueRow: { display: 'flex', alignItems: 'center', gap: 12, padding: '12px 20px', borderBottom: '1px solid #fafafa', cursor: 'pointer' },
    progress: { background: '#f0f0f0', borderRadius: 99, height: 8, overflow: 'hidden', marginTop: 6 },
    progressBar: (color: string, pct: number): React.CSSProperties => ({ height: '100%', width: `${pct}%`, background: color, borderRadius: 99 }),
    btnGhost: { background: 'none', border: 'none', color: '#1976d2', fontSize: 13, cursor: 'pointer', fontWeight: 500 },
    empty: { padding: '24px 16px', textAlign: 'center' as const, color: '#9e9e9e', fontSize: 13 },
    slaGrid: { display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, textAlign: 'center' as const },
    slaVal: (color: string): React.CSSProperties => ({ fontSize: 28, fontWeight: 700, color }),
    slaLabel: { fontSize: 12, color: '#757575', marginTop: 2 },
    alert: { background: '#ffebee', border: '1px solid #ef9a9a', borderRadius: 8, padding: '8px 12px', fontSize: 13, color: '#b71c1c', marginTop: 12 },
  };

  if (loading) return (
    <div style={{ ...s.wrap, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12 }}>
      <span style={{ fontSize: 14, color: '#757575' }}>Memuat data...</span>
    </div>
  );

  if (error) return (
    <div style={{ ...s.wrap, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontSize: 36, marginBottom: 8 }}>⚠️</div>
        <div style={{ fontWeight: 600, marginBottom: 4 }}>Gagal memuat</div>
        <div style={{ color: '#757575', fontSize: 13 }}>{error}</div>
      </div>
    </div>
  );

  const today = new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

  const rows = [
    { label: 'Terkirim', pct: (delivered.length / total) * 100, count: delivered.length, color: '#388e3c' },
    { label: 'Dalam Perjalanan', pct: (inTransit.length / total) * 100, count: inTransit.length, color: '#f57c00' },
    { label: 'Lainnya', pct: ((total - delivered.length - inTransit.length) / total) * 100, count: total - delivered.length - inTransit.length, color: '#c62828' },
  ];

  return (
    <div style={s.wrap}>
      <div style={s.header}>
        <div>
          <h1 style={s.h1}>Dashboard TMS</h1>
          <p style={s.sub}>{today}</p>
        </div>
      </div>

      <div style={s.stats}>
        {[
          { icon: '🚚', label: 'Shipment Aktif', value: activeShipments.length, color: '#1976d2', path: '/shipments' },
          { icon: '📋', label: 'Order Pending', value: pendingOrders.length, color: '#7b1fa2', path: '/orders' },
          { icon: '▶️', label: 'Dalam Perjalanan', value: inTransit.length, color: '#f57c00', path: '/shipments' },
          { icon: '✅', label: 'Terkirim', value: delivered.length, color: '#388e3c', path: '/shipments' },
          { icon: '⏱️', label: 'On-Time Rate', value: `${onTimeRate}%`, color: '#00897b', path: undefined },
        ].map(item => (
          <div key={item.label} style={s.stat} onClick={() => item.path && nav(item.path)}>
            <div style={s.icon(item.color)}>{item.icon}</div>
            <div>
              <div style={s.val}>{item.value}</div>
              <div style={s.label}>{item.label}</div>
            </div>
          </div>
        ))}
      </div>

      <div style={s.grid2}>
        <div style={s.card}>
          <div style={s.cardHead}>
            <h3 style={s.cardTitle}>Shipment Terbaru</h3>
            <button style={s.btnGhost} onClick={() => nav('/shipments')}>Lihat Semua →</button>
          </div>
          <div style={s.cardBody}>
            <table style={s.table}>
              <thead>
                <tr>
                  <th style={s.th}>Referensi</th>
                  <th style={s.th}>Rute</th>
                  <th style={s.th}>Status</th>
                </tr>
              </thead>
              <tbody>
                {recentShipments.length === 0 && (
                  <tr><td colSpan={3} style={s.empty}>Tidak ada data</td></tr>
                )}
                {recentShipments.map(s2 => {
                  const chip = statusChip(s2.status);
                  const origin = s2.originCity ? `${s2.originCity}${s2.originState ? ', ' + s2.originState : ''}` : 'N/A';
                  const dest = s2.destinationCity ? `${s2.destinationCity}${s2.destinationState ? ', ' + s2.destinationState : ''}` : 'N/A';
                  return (
                    <tr key={s2.id} style={{ cursor: 'pointer' }} onClick={() => nav(`/shipments/${s2.id}`)}>
                      <td style={s.td}><strong>{s2.referenceNumber || `SHP-${s2.id.slice(0, 6)}`}</strong></td>
                      <td style={s.td}>
                        <div>{origin}</div>
                        <div style={{ color: '#9e9e9e', fontSize: 11 }}>→ {dest}</div>
                      </td>
                      <td style={s.td}><span style={s.chip(chip.color)}>{chip.label}</span></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        <div style={s.card}>
          <div style={s.cardHead}>
            <h3 style={s.cardTitle}>Isu Aktif</h3>
            <button style={s.btnGhost} onClick={() => nav('/issues')}>Lihat Board →</button>
          </div>
          <div style={s.cardBody}>
            {activeIssues.length === 0 && <div style={s.empty}>Tidak ada isu aktif</div>}
            {activeIssues.map(issue => (
              <div key={issue.id} style={s.issueRow}>
                <span style={{ fontSize: 18, color: severityColor(issue.priority) }}>⚠</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 500 }}>{issue.title}</div>
                  <div style={{ fontSize: 11, color: '#9e9e9e' }}>{issue.sourceEntityId || 'N/A'} · {relTime(issue.createdAt)}</div>
                </div>
                <span style={{ color: '#bdbdbd' }}>›</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {slaSummary && slaSummary.total > 0 && (
        <div style={{ ...s.card, marginBottom: 16, cursor: 'pointer', padding: 20 }} onClick={() => nav('/sla')}>
          <h3 style={{ ...s.cardTitle, marginBottom: 16 }}>SLA Health</h3>
          <div style={s.slaGrid}>
            {[
              { label: 'Aktif', value: slaSummary.active, color: '#1976d2' },
              { label: 'Peringatan', value: slaSummary.warning, color: '#f57c00' },
              { label: 'Dilanggar', value: slaSummary.breached, color: '#c62828' },
              { label: 'Terpenuhi', value: slaSummary.met, color: '#388e3c' },
            ].map(item => (
              <div key={item.label}>
                <div style={s.slaVal(item.color)}>{item.value}</div>
                <div style={s.slaLabel}>{item.label}</div>
              </div>
            ))}
          </div>
          {slaSummary.breached > 0 && (
            <div style={s.alert}>⚠ {slaSummary.breached} SLA dilanggar — klik untuk detail</div>
          )}
        </div>
      )}

      <div style={{ ...s.card, padding: 20 }}>
        <h3 style={{ ...s.cardTitle, marginBottom: 16 }}>Performa Pengiriman</h3>
        {rows.map(row => (
          <div key={row.label} style={{ marginBottom: 16 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 4 }}>
              <span style={{ fontWeight: 500 }}>{row.label}</span>
              <span style={{ color: '#757575' }}>{row.count} shipment ({row.pct.toFixed(1)}%)</span>
            </div>
            <div style={s.progress}>
              <div style={s.progressBar(row.color, row.pct)} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default TmsDashboard;
