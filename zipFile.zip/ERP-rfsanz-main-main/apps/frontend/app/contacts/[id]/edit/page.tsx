'use client';
import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { useAuthStore } from '../../../../lib/store/useAuthStore';
import AppShell from '../../../../components/layout/AppShell';
import ContactForm from '../../../../components/contacts/ContactForm';
import { api } from '../../../../lib/api';
import { ArrowLeft } from 'lucide-react';

export default function EditContactPage() {
  const { token } = useAuthStore();
  const router = useRouter();
  const { id } = useParams<{ id: string }>();
  const [contact, setContact] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => { if (!token) router.push('/login'); }, [token]);

  useEffect(() => {
    if (!token || !id) return;
    api.get(`/contacts/${id}`)
      .then(r => setContact(r.data))
      .catch(() => router.push('/contacts'))
      .finally(() => setLoading(false));
  }, [token, id]);

  if (!token) return null;

  return (
    <AppShell>
      <div className="p-6 space-y-6 max-w-4xl mx-auto">
        <div className="flex items-center gap-3">
          <button onClick={() => router.back()}
            className="p-2 rounded-lg transition hover:bg-purple-50"
            style={{ border: '1px solid #EDE8F5', color: '#7367F0' }}>
            <ArrowLeft className="h-4 w-4" />
          </button>
          <div>
            <h1 className="text-xl font-bold" style={{ color: '#1E1B4B' }}>Edit Kontak</h1>
            <p className="text-sm mt-0.5" style={{ color: '#9CA3AF' }}>{contact?.name || '...'}</p>
          </div>
        </div>
        {loading ? (
          <div className="text-center py-12 text-sm" style={{ color: '#9CA3AF' }}>Memuat data...</div>
        ) : (
          <ContactForm mode="edit" id={id} initial={contact} />
        )}
      </div>
    </AppShell>
  );
}
